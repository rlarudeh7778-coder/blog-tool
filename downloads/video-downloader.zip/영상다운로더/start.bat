@echo off
setlocal
title My Video Downloader
cd /d "%~dp0"

set PY=
python --version >nul 2>nul && set PY=python
if not defined PY ( py --version >nul 2>nul && set PY=py )
if not defined PY (
    echo.
    echo  [ERROR] Python not found.
    echo  Install from https://www.python.org/downloads/
    echo  IMPORTANT: check "Add Python to PATH" during install,
    echo  then close this window and run start.bat again.
    echo.
    pause
    exit /b
)

echo.
echo  Checking pip...
%PY% -m pip --version >nul 2>nul || %PY% -m ensurepip --default-pip

echo.
echo  Installing / checking required packages...
echo  (first run may take 1-3 min)
%PY% -m pip install --upgrade --pre "yt-dlp[default]"
%PY% -m pip install --upgrade flask imageio-ffmpeg deno yt-dlp-ejs
if errorlevel 1 (
    echo.
    echo  [ERROR] Package install failed. Check your internet connection.
    echo.
    pause
    exit /b
)

echo.
echo  Starting server... Browser will open automatically.
echo  Close this window to quit.
echo.
%PY% server.py
pause
