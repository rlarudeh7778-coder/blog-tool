# -*- coding: utf-8 -*-
"""
나만의 영상 다운로더
유튜브 / 인스타그램 링크를 붙여넣으면 MP4(영상) 또는 MP3(음원)로 다운로드하는 로컬 웹 앱.
다운로드한 파일은 바탕화면에 저장됩니다. 개인 소장 용도로만 사용하세요.
"""
import os
import sys
import uuid
import shutil
import sysconfig
import threading
import subprocess
import webbrowser
from pathlib import Path

from flask import Flask, request, jsonify, Response


# ---------------------------------------------------------------------------
# 1) JS 런타임(deno) 경로를 PATH에 주입 - 유튜브가 요구하는 필수 요소
#    이게 없으면 "403 Forbidden" / "page needs to be reloaded" 오류가 납니다.
# ---------------------------------------------------------------------------
def ensure_js_runtime():
    for d in {sysconfig.get_path("scripts"),
              sysconfig.get_path("scripts", "nt_user" if os.name == "nt" else "posix_user"),
              str(Path(sys.executable).parent / "Scripts"),
              str(Path(sys.executable).parent)}:
        if d and os.path.isdir(d) and d not in os.environ.get("PATH", ""):
            os.environ["PATH"] = d + os.pathsep + os.environ.get("PATH", "")
    try:
        from deno._find_deno import find_deno_bin
        p = find_deno_bin()
        if p:
            os.environ["PATH"] = str(Path(p).parent) + os.pathsep + os.environ["PATH"]
            return str(p)
    except Exception:
        pass
    return shutil.which("deno") or shutil.which("node")


JS_RUNTIME = ensure_js_runtime()

try:
    import yt_dlp
except ImportError:
    print("yt-dlp is not installed. Run start.bat instead.")
    sys.exit(1)

app = Flask(__name__)


@app.after_request
def add_cors(resp):
    # 리치원 블로그 툴(깃허브 페이지)의 downloader.html이 이 로컬 서버를 호출할 수 있도록 허용.
    # Allow-Private-Network는 https 사이트 → localhost 요청을 막는
    # 크롬의 Private Network Access 정책을 통과하기 위해 필요합니다.
    resp.headers["Access-Control-Allow-Origin"] = "*"
    resp.headers["Access-Control-Allow-Headers"] = "Content-Type"
    resp.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
    resp.headers["Access-Control-Allow-Private-Network"] = "true"
    resp.headers["Access-Control-Max-Age"] = "86400"
    return resp


def get_desktop():
    """실제 바탕화면 경로 (OneDrive 바탕화면 포함) 탐지."""
    if os.name == "nt":
        try:
            import ctypes.wintypes
            buf = ctypes.create_unicode_buffer(ctypes.wintypes.MAX_PATH)
            ctypes.windll.shell32.SHGetFolderPathW(None, 0, None, 0, buf)  # CSIDL_DESKTOP
            if buf.value:
                return Path(buf.value)
        except Exception:
            pass
    return Path.home() / "Desktop"


DOWNLOAD_DIR = get_desktop()
DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)

JOBS = {}

# 403 회피 재시도 순서: 기본값 -> 다른 클라이언트 -> 브라우저 쿠키 사용
# (name, player_client, cookies_from_browser)
ATTEMPTS = [
    ("기본", None, None),
    ("TV 방식", ["tv"], None),
    ("iOS 방식", ["ios"], None),
    ("Chrome 로그인 정보", None, "chrome"),
    ("Edge 로그인 정보", None, "edge"),
    ("Firefox 로그인 정보", None, "firefox"),
]


def _browser_cookie_exists(name):
    """해당 브라우저의 쿠키/프로필 폴더가 실제로 있는지 확인."""
    home = Path.home()
    if os.name == "nt":
        local = Path(os.environ.get("LOCALAPPDATA") or (home / "AppData/Local"))
        roaming = Path(os.environ.get("APPDATA") or (home / "AppData/Roaming"))
        cands = {
            "chrome": [local / "Google/Chrome/User Data"],
            "edge": [local / "Microsoft/Edge/User Data"],
            "firefox": [roaming / "Mozilla/Firefox/Profiles"],
        }.get(name, [])
    elif sys.platform == "darwin":
        app = home / "Library/Application Support"
        cands = {
            "chrome": [app / "Google/Chrome"],
            "edge": [app / "Microsoft Edge"],
            "firefox": [app / "Firefox/Profiles"],
        }.get(name, [])
    else:
        cfg = home / ".config"
        cands = {
            "chrome": [cfg / "google-chrome"],
            "edge": [cfg / "microsoft-edge"],
            "firefox": [home / ".mozilla/firefox"],
        }.get(name, [])
    for c in cands:
        try:
            if c.exists():
                return True
        except Exception:
            pass
    return False


_AVAIL_BROWSERS = None


def effective_attempts():
    """설치된 브라우저의 쿠키 시도만 남긴다(없는 브라우저는 건너뜀 -> 쿠키 DB 오류 방지)."""
    global _AVAIL_BROWSERS
    if _AVAIL_BROWSERS is None:
        _AVAIL_BROWSERS = {b for b in ("chrome", "edge", "firefox") if _browser_cookie_exists(b)}
    return [a for a in ATTEMPTS if a[2] is None or a[2] in _AVAIL_BROWSERS]


def find_ffmpeg():
    path = shutil.which("ffmpeg")
    if path:
        return path
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        return None


FFMPEG = find_ffmpeg()


def base_opts(clients=None, cookies=None):
    opts = {
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
        "outtmpl": str(DOWNLOAD_DIR / "%(title).120s.%(ext)s"),
        "windowsfilenames": True,
        "retries": 5,
        "fragment_retries": 5,
        "extractor_retries": 2,
        "geo_bypass": True,
    }
    if clients:
        opts["extractor_args"] = {"youtube": {"player_client": clients}}
    if cookies:
        opts["cookiesfrombrowser"] = (cookies,)
    if FFMPEG:
        opts["ffmpeg_location"] = str(Path(FFMPEG).parent)
    return opts


@app.route("/api/info", methods=["POST"])
def api_info():
    url = (request.json or {}).get("url", "").strip()
    if not url:
        return jsonify({"error": "링크를 입력해 주세요."}), 400
    last = ""
    for _, clients, cookies in effective_attempts():
        try:
            with yt_dlp.YoutubeDL({**base_opts(clients, cookies), "skip_download": True}) as ydl:
                info = ydl.extract_info(url, download=False)
            if info.get("_type") == "playlist" and info.get("entries"):
                info = info["entries"][0]
            dur = info.get("duration") or 0
            return jsonify({
                "title": info.get("title", "제목 없음"),
                "thumbnail": info.get("thumbnail", ""),
                "uploader": info.get("uploader") or info.get("channel") or "",
                "duration": f"{int(dur)//60}:{int(dur)%60:02d}" if dur else "",
            })
        except Exception as e:
            last = str(e)[:200]
    return jsonify({"error": f"정보를 가져올 수 없습니다: {last}"}), 400


def build_opts(clients, cookies, fmt, hook):
    opts = {**base_opts(clients, cookies), "progress_hooks": [hook]}
    if fmt == "mp3":
        opts.update({
            "format": "bestaudio/best",
            "postprocessors": [{
                "key": "FFmpegExtractAudio",
                "preferredcodec": "mp3",
                "preferredquality": "192",
            }],
        })
    else:
        if FFMPEG:
            opts.update({
                "format": "bestvideo[height<=1080]+bestaudio/best[height<=1080]/best",
                "merge_output_format": "mp4",
            })
        else:
            opts["format"] = "best[ext=mp4]/best"
    return opts


def run_download(job_id, url, fmt):
    job = JOBS[job_id]

    def hook(d):
        if d["status"] == "downloading":
            total = d.get("total_bytes") or d.get("total_bytes_estimate")
            if total:
                job["percent"] = round(d.get("downloaded_bytes", 0) / total * 100, 1)
        elif d["status"] == "finished":
            job["status"] = "processing"
            job["percent"] = 100

    if fmt == "mp3" and not FFMPEG:
        job.update(status="error", error="ffmpeg를 찾을 수 없습니다. start.bat으로 다시 실행해 주세요.")
        return

    last_err = ""
    eff = effective_attempts()
    for idx, (label, clients, cookies) in enumerate(eff):
        try:
            job.update(status="downloading", percent=0,
                       note=("" if idx == 0 else f"{label}으로 재시도 ({idx + 1}/{len(eff)})"))
            with yt_dlp.YoutubeDL(build_opts(clients, cookies, fmt, hook)) as ydl:
                info = ydl.extract_info(url, download=True)
            if info.get("_type") == "playlist" and info.get("entries"):
                info = info["entries"][0]
            job.update(status="done", percent=100, title=info.get("title", ""), note="")
            return
        except Exception as e:
            msg = str(e)
            low = msg.lower()
            if "cookies database" in low or "could not find" in low or "could not copy" in low:
                if not last_err:
                    last_err = msg
                continue
            last_err = msg

    hint = ""
    low = last_err.lower()
    if not JS_RUNTIME:
        hint = " → JS 런타임이 없습니다. update.bat을 실행해 주세요."
    elif "cookies database" in low or "could not find" in low:
        hint = " → 크롬(또는 엣지)에서 유튜브에 로그인해 두고 다시 시도해 주세요."
    elif "403" in last_err or "Forbidden" in last_err:
        hint = " → update.bat 실행 후 다시 시도해 보세요. 그래도 안 되면 크롬에서 유튜브에 로그인해 두세요."
    elif "Sign in" in last_err or "bot" in last_err.lower():
        hint = " → 크롬에서 유튜브에 로그인한 뒤 다시 시도해 보세요."
    job.update(status="error", error=last_err[:250] + hint, note="")


@app.route("/api/download", methods=["POST"])
def api_download():
    data = request.json or {}
    url = data.get("url", "").strip()
    fmt = data.get("format", "mp4")
    if not url:
        return jsonify({"error": "링크를 입력해 주세요."}), 400
    job_id = uuid.uuid4().hex[:12]
    JOBS[job_id] = {"status": "starting", "percent": 0, "title": "", "error": "", "note": ""}
    threading.Thread(target=run_download, args=(job_id, url, fmt), daemon=True).start()
    return jsonify({"job_id": job_id})


@app.route("/api/progress/<job_id>")
def api_progress(job_id):
    return jsonify(JOBS.get(job_id, {"status": "error", "error": "작업을 찾을 수 없습니다."}))


@app.route("/api/status")
def api_status():
    return jsonify({
        "ytdlp": getattr(yt_dlp.version, "__version__", "?"),
        "js": bool(JS_RUNTIME),
        "ffmpeg": bool(FFMPEG),
    })


@app.route("/api/open-folder", methods=["POST"])
def api_open_folder():
    try:
        if os.name == "nt":
            os.startfile(str(DOWNLOAD_DIR))  # noqa
        elif sys.platform == "darwin":
            subprocess.Popen(["open", str(DOWNLOAD_DIR)])
        else:
            subprocess.Popen(["xdg-open", str(DOWNLOAD_DIR)])
        return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


HTML = """<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>나만의 영상 다운로더</title>
<style>
  * { margin:0; padding:0; box-sizing:border-box; font-family:'Segoe UI','Malgun Gothic',sans-serif; }
  body { min-height:100vh; background:linear-gradient(135deg,#0f172a 0%,#1e293b 50%,#312e81 100%); color:#e2e8f0;
         display:flex; align-items:center; justify-content:center; padding:24px; }
  .card { width:100%; max-width:640px; background:rgba(255,255,255,.06); border:1px solid rgba(255,255,255,.12);
          border-radius:20px; padding:36px; backdrop-filter:blur(12px); box-shadow:0 20px 60px rgba(0,0,0,.4); }
  h1 { font-size:26px; text-align:center; margin-bottom:6px;
       background:linear-gradient(90deg,#f87171,#fb923c,#a78bfa); -webkit-background-clip:text; -webkit-text-fill-color:transparent; }
  .sub { text-align:center; color:#94a3b8; font-size:13px; margin-bottom:20px; }
  .warn { display:none; margin-bottom:18px; padding:12px; border-radius:10px; font-size:13px; text-align:center;
          background:rgba(251,146,60,.12); border:1px solid rgba(251,146,60,.4); color:#fdba74; }
  input[type=text] { width:100%; padding:14px 16px; border-radius:12px; border:1px solid rgba(255,255,255,.15);
          background:rgba(0,0,0,.3); color:#fff; font-size:15px; outline:none; }
  input[type=text]:focus { border-color:#a78bfa; }
  .fmt { display:flex; gap:10px; margin:16px 0; }
  .fmt button { flex:1; padding:11px; border-radius:12px; border:1px solid rgba(255,255,255,.15);
          background:rgba(0,0,0,.25); color:#94a3b8; font-size:14px; cursor:pointer; transition:.2s; }
  .fmt button.on { background:linear-gradient(90deg,#7c3aed,#db2777); color:#fff; border-color:transparent; font-weight:600; }
  .go { width:100%; padding:15px; border:none; border-radius:12px; font-size:16px; font-weight:700; cursor:pointer;
        background:linear-gradient(90deg,#ef4444,#f97316); color:#fff; transition:.2s; }
  .go:hover { filter:brightness(1.1); }
  .go:disabled { opacity:.5; cursor:not-allowed; }
  .preview { display:none; margin:18px 0 0; gap:14px; align-items:center; background:rgba(0,0,0,.25);
             border-radius:14px; padding:12px; }
  .preview img { width:120px; border-radius:10px; }
  .preview .t { font-size:14px; font-weight:600; line-height:1.4; }
  .preview .u { font-size:12px; color:#94a3b8; margin-top:4px; }
  .bar-wrap { display:none; margin-top:18px; }
  .bar-bg { height:10px; background:rgba(255,255,255,.1); border-radius:6px; overflow:hidden; }
  .bar { height:100%; width:0%; background:linear-gradient(90deg,#34d399,#22d3ee); transition:width .3s; }
  .bar-txt { font-size:13px; color:#94a3b8; margin-top:8px; text-align:center; }
  .msg { display:none; margin-top:18px; padding:14px; border-radius:12px; font-size:14px; text-align:center; line-height:1.6; }
  .msg.ok { background:rgba(52,211,153,.12); border:1px solid rgba(52,211,153,.4); color:#6ee7b7; }
  .msg.err { background:rgba(248,113,113,.12); border:1px solid rgba(248,113,113,.4); color:#fca5a5; }
  .open-btn { display:none; width:100%; margin-top:10px; padding:12px; border-radius:12px; cursor:pointer;
        border:1px solid rgba(255,255,255,.2); background:transparent; color:#e2e8f0; font-size:14px; }
  .foot { text-align:center; font-size:11px; color:#64748b; margin-top:24px; }
</style>
</head>
<body>
<div class="card">
  <h1>나만의 영상 다운로더</h1>
  <div class="sub">유튜브 · 인스타그램 링크를 붙여넣으세요</div>
  <div class="warn" id="warn"></div>
  <input type="text" id="url" placeholder="https://www.youtube.com/watch?v=..." autofocus>
  <div class="fmt">
    <button id="fmtMp4" class="on">&#127916; 영상 (MP4)</button>
    <button id="fmtMp3">&#127925; 음원 (MP3)</button>
  </div>
  <button class="go" id="go">다운로드</button>
  <div class="preview" id="preview">
    <img id="pvImg" src="" alt="">
    <div><div class="t" id="pvTitle"></div><div class="u" id="pvUp"></div></div>
  </div>
  <div class="bar-wrap" id="barWrap">
    <div class="bar-bg"><div class="bar" id="bar"></div></div>
    <div class="bar-txt" id="barTxt">준비 중...</div>
  </div>
  <div class="msg" id="msg"></div>
  <button class="open-btn" id="openBtn">&#128194; 바탕화면 열기</button>
  <div class="foot" id="foot">저장 위치: 바탕화면 &nbsp;|&nbsp; 개인 소장 용도로만 사용하세요</div>
</div>
<script>
let fmt = 'mp4';
const $ = id => document.getElementById(id);
$('fmtMp4').onclick = () => { fmt='mp4'; $('fmtMp4').classList.add('on'); $('fmtMp3').classList.remove('on'); };
$('fmtMp3').onclick = () => { fmt='mp3'; $('fmtMp3').classList.add('on'); $('fmtMp4').classList.remove('on'); };
$('url').addEventListener('keydown', e => { if (e.key === 'Enter') $('go').click(); });

fetch('/api/status').then(r => r.json()).then(s => {
  $('foot').textContent = '저장 위치: 바탕화면 | yt-dlp ' + s.ytdlp + ' | 개인 소장 용도로만';
  if (!s.js) {
    $('warn').textContent = 'JS 런타임이 없어 유튜브 다운로드가 실패합니다. update.bat을 실행해 주세요.';
    $('warn').style.display = 'block';
  }
}).catch(()=>{});

function clean(t) { return String(t || '').replace(/\\u001b\\[[0-9;]*m/g, ''); }

function showMsg(text, ok) {
  const m = $('msg'); m.textContent = clean(text); m.className = 'msg ' + (ok ? 'ok' : 'err'); m.style.display = 'block';
}

$('go').onclick = async () => {
  const url = $('url').value.trim();
  if (!url) { showMsg('링크를 입력해 주세요.', false); return; }
  $('go').disabled = true;
  $('msg').style.display = 'none'; $('openBtn').style.display = 'none';
  $('preview').style.display = 'none';
  $('barWrap').style.display = 'block'; $('bar').style.width = '0%';
  $('barTxt').textContent = '영상 정보 확인 중...';

  fetch('/api/info', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({url}) })
    .then(r => r.json()).then(info => {
      if (!info.error) {
        $('pvImg').src = info.thumbnail || '';
        $('pvTitle').textContent = info.title;
        $('pvUp').textContent = (info.uploader || '') + (info.duration ? ' | ' + info.duration : '');
        $('preview').style.display = 'flex';
      }
    }).catch(()=>{});

  try {
    const r = await fetch('/api/download', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({url, format:fmt}) });
    const d = await r.json();
    if (d.error) throw new Error(d.error);
    poll(d.job_id);
  } catch (e) {
    showMsg(e.message, false); $('go').disabled = false; $('barWrap').style.display = 'none';
  }
};

function poll(jobId) {
  const timer = setInterval(async () => {
    try {
      const s = await (await fetch('/api/progress/' + jobId)).json();
      if (s.status === 'downloading' || s.status === 'starting') {
        $('bar').style.width = (s.percent || 0) + '%';
        $('barTxt').textContent = (s.note ? s.note + ' - ' : '') + '다운로드 중... ' + (s.percent || 0) + '%';
      } else if (s.status === 'processing') {
        $('bar').style.width = '100%'; $('barTxt').textContent = '변환 중...';
      } else if (s.status === 'done') {
        clearInterval(timer);
        $('barWrap').style.display = 'none';
        showMsg('완료! 바탕화면에 "' + (s.title || '파일') + '" 저장됨', true);
        $('openBtn').style.display = 'block';
        $('go').disabled = false;
      } else if (s.status === 'error') {
        clearInterval(timer);
        $('barWrap').style.display = 'none';
        showMsg('오류: ' + s.error, false);
        $('go').disabled = false;
      }
    } catch (e) {}
  }, 700);
}

$('openBtn').onclick = () => fetch('/api/open-folder', { method:'POST' });
</script>
</body>
</html>"""


@app.route("/")
def index():
    return Response(HTML, mimetype="text/html")


if __name__ == "__main__":
    port = 8756
    print(f"\n  My Video Downloader -> http://localhost:{port}")
    print(f"  Save folder: {DOWNLOAD_DIR}")
    print(f"  yt-dlp: {getattr(yt_dlp.version, '__version__', '?')}")
    print(f"  JS runtime: {JS_RUNTIME or 'NOT FOUND -> run update.bat!'}")
    if not FFMPEG:
        print("  [WARN] ffmpeg not found.")
    threading.Timer(1.0, lambda: webbrowser.open(f"http://localhost:{port}")).start()
    app.run(host="127.0.0.1", port=port, debug=False)
