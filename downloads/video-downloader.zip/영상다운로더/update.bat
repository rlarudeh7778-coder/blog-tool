@echo off
setlocal
title Update Downloader
cd /d "%~dp0"

set PY=
python --version >nul 2>nul && set PY=python
if not defined PY ( py --version >nul 2>nul && set PY=py )
if not defined PY (
    echo  [ERROR] Python not found.
    pause
    exit /b
)

echo.
echo  Updating yt-dlp and installing the JavaScript runtime...
echo  (YouTube now requires a JS runtime - this fixes 403 Forbidden errors)
echo.
%PY% -m pip install --upgrade --pre "yt-dlp[default]"
%PY% -m pip install --upgrade deno yt-dlp-ejs
echo.
echo  Checking JS runtime...
%PY% -c "from deno._find_deno import find_deno_bin; print('  JS runtime OK:', find_deno_bin())" 2>nul || echo   [WARN] JS runtime install failed.
echo.
echo  Done. Close this window and run start.bat again.
echo.
pause
